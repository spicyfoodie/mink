# -*- coding: utf-8 -*-
# sdtfile/__init__.py

from .sdtfile import __doc__, __all__, __version__
from .sdtfile import *
