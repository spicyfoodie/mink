# -*- coding: utf-8 -*-
# lfdfiles/__init__.py

from .lfdfiles import __doc__, __all__, __version__
from .lfdfiles import *
