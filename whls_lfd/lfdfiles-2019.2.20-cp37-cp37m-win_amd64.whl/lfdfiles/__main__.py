# -*- coding: utf-8 -*-
# lfdfiles/__main__.py

"""Lfdfiles package command line script."""

import sys

from .lfdfiles import main

sys.exit(main())
